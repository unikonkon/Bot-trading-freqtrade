# เงื่อนไขสัญญาณตามโค้ดที่แนบ

## SMC Adaptive V2

พารามิเตอร์: `{"internalSize":20,"trendLength":14,"trendMult":1,"fastPeriod":50,"trendPeriod":200,"atrPeriod":14,"adxPeriod":14,"adxThreshold":15,"confluenceBars":6,"stopAtr":3,"trailAtr":2,"breakEvenAtr":1.5,"breakEvenBufferPct":0.35,"maxHoldBars":200,"cooldownBars":6,"maxVolatilityRatio":2.5,"maxExtensionAtr":2}`

SMC internal pivots + Trendlines pivots ใช้ confirmed เท่านั้น และรอให้มี pivot จริงก่อนใช้เส้น. BUY เมื่อ Trendlines breakUp ยังไม่หมดอายุ confluenceBars, SMC bullish, close > upper และ EMA เทรนด์, EMA เร็วเหนือ EMA เทรนด์และไม่ลดลง, EMA เทรนด์เพิ่มจาก 24 แท่งก่อน, +DI > -DI, ADX >= adxThreshold, แท่งเขียวและไม่ไกล EMA เร็วเกิน maxExtensionAtr. งดเข้าเมื่อ ATR ratio > maxVolatilityRatio หรือ range > 4 ATR หรือ cooldown. Stop เริ่ม stopAtr×ATR×clamp(ratio,1,1.5), เลื่อนขึ้นตาม peak CLOSE − trailAtr×ATR และเลื่อนถึง signal-entry close + breakEvenBufferPct เมื่อ peak close เพิ่ม >= breakEvenAtr×ATR ณ เข้า. Buffer ไม่รับประกันคุ้มต้นทุน/gap. ไม่มี fixed target. SELL เมื่อ CLOSE <= stop (รวม stop ที่เพิ่งเลื่อน), bearish SMC/Trendlines breakdown พร้อม close < fast EMA หรือ maxHoldBars. ทุก exit fill ตาม engine ไม่สมมติ fill ที่ stop ระหว่างแท่ง. Reset trade state ที่ startIndex; ดู reason/regime/stop/ADX/DI รายแท่ง

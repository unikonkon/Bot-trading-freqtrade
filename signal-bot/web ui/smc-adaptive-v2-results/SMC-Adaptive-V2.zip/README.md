# Signal bot — Export ผลคำนวณและโค้ด

รอบทดสอบ smc-adaptive-v2-offline-analysis

BTCUSDT / 1h; 1 กลยุทธ์; 8399 แท่งทดสอบ + 1000 warmup

## คำนวณซ้ำ

ใช้ Node.js 20+ รันจากโฟลเดอร์ที่แตก ZIP:

```bash
npm ci
npm run replay
```

ติดตั้ง dependency ครั้งแรกต้องใช้อินเทอร์เน็ต หลังติดตั้งแล้ว replay ไม่เรียก Binance/Telegram ตรวจ SHA-256 ทุกไฟล์ใน manifest ก่อนคำนวณ และตรวจผลทั้งหมดตรงกับ calculations/*.json ก่อนเขียน recomputed/*.json

## ไฟล์

- config.json: พารามิเตอร์ที่ใช้ในรอบเดิม ไม่ใช่ฟอร์มที่แก้ภายหลัง
- input-klines.json: KlineData[] ที่แปลงจาก Binance รวม warmup ไม่ใช่ raw array ต้นฉบับ
- input-klines.csv: แท่งทั้งหมดพร้อม isWarmup
- calculations/*.json: indicator ของกลยุทธ์ที่เลือกแบบเต็ม รวม warmup, series, records และ simulations
- signals/*.csv / *.json: เฉพาะช่วงทดสอบ รวม HOLD พร้อมค่าปัจจุบัน/ก่อนหน้า และ events
- trades/*.csv: เทรดจำลองแต่ละโหมด แยกจากสัญญาณ
- summary.csv: สรุปผลการจำลอง
- rules.md: เงื่อนไขจริงของกลยุทธ์ที่เลือก
- lib/ และ signal-bot/web ui/: โค้ดคำนวณร่วม snapshot ตอนเริ่ม server; shared library มีครบทุกกลยุทธ์ แต่ replay รันเฉพาะกลยุทธ์ที่เลือก

## ใช้กับ API อื่น

นำ raw JSON จาก Binance หรือ api/klines/route.ts ไปส่งเข้า evaluateKlines ใน signal-bot/web ui/evaluate-klines.ts:

```ts
import { evaluateKlines } from './signal-bot/web ui/evaluate-klines';
const output = evaluateKlines(rawKlines, 'smc_adaptive_v2', {"internalSize":20,"trendLength":14,"trendMult":1,"fastPeriod":50,"trendPeriod":200,"atrPeriod":14,"adxPeriod":14,"adxThreshold":15,"confluenceBars":6,"stopAtr":3,"trailAtr":2,"breakEvenAtr":1.5,"breakEvenBufferPct":0.35,"maxHoldBars":200,"cooldownBars":6,"maxVolatilityRatio":2.5,"maxExtensionAtr":2});
// [{ openTime, signalTime, price, signal: 'BUY' | 'SELL' | 'HOLD' }]
```

adapter รับข้อมูลที่เรียงเวลาและตัดแท่งไม่ปิดเอง; หากต้องการผลตรงชุดนี้ ใช้ input-klines.json + params ใน config และ computeSignals ตาม replay ซึ่งรวม warmup เดียวกัน

## ความหมายและข้อจำกัด

เวลาใน CSV เป็น UTC ISO หรือ epoch milliseconds; UI แสดง Asia/Bangkok. signalTime = closeTime. index และ event indices อ้าง input-klines.json รวม warmup เสมอ ไม่ใช่เลขแถว CSV. null คือไม่มีค่า ไม่แปลงเป็น 0. CSV ใช้ UTF-8 BOM สำหรับภาษาไทย

BUY/SELL เป็นสัญญาณ ไม่ใช่การส่งคำสั่งซื้อขายหรือการส่ง Telegram. RSI อาจส่งสัญญาณติดกันหลายแท่ง. HOLD อาจเกิดจากไม่ผ่านเงื่อนไขหรือข้อมูลเตรียมไม่พอ. โครงสร้าง SMC/OB บางรายการมีสถานะสุดท้ายของชุดข้อมูล ไม่ใช่ snapshot สถานะทุกแท่ง; records.events ใช้เหตุการณ์ที่ index ของแท่งนั้น

เปิดแท่งถัดไป: Long เต็มพอร์ต เริ่ม 100 หน่วย ทบต้น หัก fee/slippage ต่อขา; drawdown รวมมูลค่าถือ ณ ปิดแท่ง. โหมดเดิม: ราคาปิดแท่งสัญญาณ ผลรวม % รายเทรด ไม่มี slippage และ drawdown เป็นจุดเปอร์เซ็นต์; เวลาเทรดยังคง openTime ตาม engine เดิม. ทั้งสองโหมดบังคับปิดท้ายข้อมูล

ที่มาราคาคือ backend เดิมที่ดึง Binance public klines โดยตรง รูปแบบเดียวกับ api/klines/route.ts ไม่ได้เรียก Next.js route นี้ ข้อมูลจากรอบเดิม ไม่มีการดึงใหม่ตอน Export. ทุกกลยุทธ์ใช้ confirmed pivots; ประวัติสะสมอาจต่างจาก rolling window ของบอทจริง

- Offline replay using the original 10-36 export candles and frozen SMC Adaptive V2 parameters
